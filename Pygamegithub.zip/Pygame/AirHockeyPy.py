import pygame
import random
import os

pygame.init()

screen = pygame.display.set_mode((1519, 676))
pygame.display.set_caption("Air Hockey")

Player = pygame.image.load(os.path.join("AirHockey", "air paddle 2.png"))
cpu = pygame.image.load(os.path.join("AirHockey", "airpaddle.png"))
puck = pygame.image.load(os.path.join("AirHockey", "puck.png"))
Rink = pygame.image.load(os.path.join("AirHockey", "Rink.png"))


def player():
    screen.blit(Player, (100, 275))

def opponent():
    screen.blit(cpu, (1200, 275))
     
    
running = True
while running:

    screen.fill((0, 0, 0))
    screen.blit(Rink, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False




    player()
    opponent()
    pygame.display.update()
